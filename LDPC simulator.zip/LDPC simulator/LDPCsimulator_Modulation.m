clear
clc

%--------------------------------------------------------------------------
%-----Set-Simulation-Parameters--------------------------------------------
%--------------------------------------------------------------------------
%snrs = [30 31];      %SNR values
snrs = 30;
codeRate = 1/4; %Possible values for codeRate are 1/4, 1/3, 2/5, 1/2, 3/5, 2/3, 3/4, 4/5, 5/6, 8/9, and 9/10. The block length of the code is 64800
mod_order = 4;  %PSK Modulation Order
%frames = 2500;  %Number of frames (fame size is 64800 bits) to be simulated
frames = 10;
%--------------------------------------------------------------------------
rounds = size(snrs,2);
messageLength = round(64800*codeRate);
for run = 1:1:rounds
framepattern = [];    
snrvalue = snrs(run);
H = dvbs2ldpc(codeRate);
errors = 0;
hEnc = comm.LDPCEncoder(H);
hMod = comm.PSKModulator(mod_order, 'BitInput',true)
hChan = comm.MIMOChannel('MaximumDopplerShift', 0, 'NumTransmitAntennas',1,...
                         'NumReceiveAntennas',1, 'TransmitCorrelationMatrix', 1,...
                         'ReceiveCorrelationMatrix', 1, 'PathGainsOutputPort', true,...
                         'RandomStream', 'mt19937ar with seed');
hAWGN = comm.AWGNChannel('NoiseMethod','Signal to noise ratio (SNR)','SNR',snrvalue);
hDemod = comm.PSKDemodulator(mod_order, 'BitOutput',true,'DecisionMethod','Approximate log-likelihood ratio');                         
hDec = comm.LDPCDecoder(H,'DecisionMethod', 'Soft decision');
for counter = 1:frames
    receiveddataBits = [];
    data           = logical(randi([0 1], messageLength, 1));
    %data = randi([0 1], messageLength, 1);
    encodedData    = step(hEnc, data); 
    modSignal      = step(hMod, encodedData);
    %Transmit through Rayleigh and AWGN channels
    [chanOut, pathGains] = step(hChan, modSignal);  
    receivedSignal = step(hAWGN, chanOut);
    demodSignal    = step(hDemod, receivedSignal);
    %receivedBits   = step(hDec, demodSignal);
    %receivedBits   = step(hDec, encodedData);
    norder = 4;
   maxlag=0;nsamp=0;overlap=0;flag='biased';k1=0;k2=0;
   y_cum = cumest(demodSignal,norder,maxlag,nsamp,overlap,flag,k1,k2)
   %y_cum = cumest(receivedBits,norder,maxlag,nsamp,overlap,flag,k1,k2)
end 
end

