EbN0dB = 4;
maxiters = 8;
load a_presentation_for_Prof_Chang/My_code/modulation_classification/NR_1_2_20.txt
B = NR_1_2_20;
[mb,nb] = size(B);
z = 20;

Slen = sum(B(:)~=-1); %number of non -1 in B

treg = zeros(max(sum(B ~= -1,2)),z); %register storage for row processing

k = (nb-mb)*z; %number of message bits
n = nb*z; %number of codeword bits

Rate = k/n;
EbN0 = 10^(EbN0dB/10);
sigma = sqrt(1/(2*Rate*EbN0));

Nbiterrs = 0; Nblkerrs = 0; Nblocks = 1;

    msg = zeros(1,k);
    
    %Encoding
    cword = zeros(1,n); %BPSK bit to symbol conversion
    
    s = 1 - 2*cword; %BPSK bit to symbol conversion
    r = s + sigma*randn(1,n); %AWGN channel I
    
%Soft-decision, iterative message-passing layered decoding
L = r; %total belief
itr = 0; %iteration number
R = zeros(Slen,z); %storage for row processing

while itr < maxiters
    Ri = 0;
    for lyr = 1:mb
       ti = 0; %number of non -1 in row=lyr
       for col = 1:nb
           if B(lyr,col) ~= -1
               ti = ti + 1;
               Ri = Ri + 1;
               %Subtraction and row alignment
               L((col-1)*z+1:col*z) = L((col-1)*z+1:col*z)-R(Ri,:);
               %Row alignment and store in treg
               treg(ti,:) = mul_sh(L((col-1)*z+1:col*z),B(lyr,col));
            end
       end
       %minsum on treg: ti x z
       for i1 = 1:z  %treg(1:ti,i)
           [min1,pos] = min(abs(treg(1:ti,i1))); %first minimum
           min2 = min(abs(treg([1:pos-1   pos+1:ti],i1))); %second minimum
           S = sign(treg(1:ti,i1));
           parity = prod(S);
           treg(1:ti,i1) = min1; %absolute value for all
           treg(pos,i1) = min2; %absolute value for min1 position
           treg(1:ti,i1) = parity*S.*treg(1:ti,i1); %assign signs
       end
       %column alignment, addition and store in R
       Ri = Ri - ti; %reset the storage counter
       ti = 0;
       for col = 1:nb
           if B(lyr,col) ~= -1
               Ri    = Ri + 1;
               ti = ti + 1;
               %Column alignment
               R(Ri,:) = mul_sh(treg(ti,:),z-B(lyr,col));
               %Addition
               L((col-1)*z+1:col*z) = L((col-1)*z+1:col*z)+R(Ri,:);
           end
       end
   end
   msg_cap = L(1:k) < 0; %decision 
    itr = itr + 1;
end

% Counting errors
Nerrs = sum(msg ~= msg_cap);
if Nerrs > 0
    Nbiterrs = Nbiterrs + Nerrs;
    Nblkerrs = Nblkerrs + 1;
end

BER_sim = Nbiterrs/k/Nblocks;
FER_sim = Nblkerrs/Nblocks;

disp([EbN0dB FER_sim BER_sim Nblkerrs Nbiterrs Nblocks])
