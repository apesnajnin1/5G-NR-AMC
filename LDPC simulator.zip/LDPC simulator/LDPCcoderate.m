p = dvbs2ldpc(2/3)
enc = comm.LDPCEncoder(p);
msgLength = size(p,2) - size(p,1)