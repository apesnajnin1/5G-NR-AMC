% Cumulant Calculation for Different Rate LDPC for QPSK Modulation
clc;
clear all;

modulationTypes = categorical("QPSK");

% waveform generation
%numFramesPerModType = 10000;
numFramesPerModType = 10;
percentTrainingSamples = 80;
percentValidationSamples = 10;
percentTestSamples = 10;


sps = 8;                % Samples per symbol
spf = 1024;             % Samples per frame
symbolsPerFrame = spf / sps;
fs = 200e3;             % Sample rate
fc = 900e6;     % Center frequencies

codingrate = 1/2; % *** it should be variable
EbN0dB = 2;
offset = 2;

% Add noise
SNR = 30;
std = sqrt(10.^(-SNR/10)); 


awgnChannel = comm.AWGNChannel(...
  'NoiseMethod', 'Signal to noise ratio (SNR)', ...
  'SignalPower', 1, ...
  'SNR', SNR); 

%Rician Multipath

multipathChannel = comm.RicianChannel(...
  'SampleRate', fs, ...
  'PathDelays', [0 1.8 3.4]/fs, ...
  'AveragePathGains', [0 -2 -10], ...
  'KFactor', 4, ...
  'MaximumDopplerShift', 4);

%Clock Offset

maxDeltaOff = 5;
deltaOff = (rand()*2*maxDeltaOff) - maxDeltaOff;
C = 1 + (deltaOff/1e6); 

%Frequency Offset
fq_offset = -(C-1)*fc(1);
frequencyShifter = comm.PhaseFrequencyOffset(...
  'SampleRate', fs, ...
  'FrequencyOffset', fq_offset); 

%Sampling Rate Offset
fadingchannel = helperModClassTestChannel(...
  'SampleRate', fs, ...
  'SNR', SNR, ...
  'PathDelays', [0 1.8 3.4] / fs, ...
  'AveragePathGains', [0 -2 -10], ...
  'KFactor', 4, ...
  'MaximumDopplerShift', 4, ...
  'MaximumClockOffset', 5, ...
  'CenterFrequency', 900e6);

fad_chInfo = info(fadingchannel)
%for SISO
siso_channel = comm.MIMOChannel('MaximumDopplerShift', 0, 'NumTransmitAntennas',1,...
                        'NumReceiveAntennas',1, 'TransmitCorrelationMatrix', 1,...
                       'ReceiveCorrelationMatrix', 1, 'PathGainsOutputPort', true,...
                      'RandomStream', 'mt19937ar with seed');

channelInfo = info(siso_channel);
%chInfo = info(channel)  

% Set the random number generator to a known state to be able to regenerate
% the same frames every time the simulation is run
rng(1235)
tic

numModulationTypes = length(modulationTypes);


frameStore = helperModClassFrameStore(...
  numFramesPerModType*numModulationTypes, spf, modulationTypes);
transDelay = 50;



for modType = 1:numModulationTypes
  fprintf('%s - Generating %s frames\n', ...
    datestr(toc/86400,'HH:MM:SS'), modulationTypes(modType))
  numSymbols = (numFramesPerModType / sps);
  dataSrc = getSource(modulationTypes(modType), sps, 2*spf, fs);
  modulator = getModulator(modulationTypes(modType), sps, fs);
  
  
    % Digital modulation types use a center frequency of 900 MHz
    %channel.CenterFrequency = 900e6;
    fadingchannel.CenterFrequency = 900e6;
   

  for p=1:numFramesPerModType
    % Generate random data
    s = dataSrc();
    
    % LDPC Coding 
    x = getldpcrate(s, codingrate, EbN0dB, SNR);
    
    % Modulate
    m = modulator(x);
    m = m';
    channelout = siso_channel(m);
    
    % Pass through independent channels
    rxSamples = fadingchannel(channelout); 
    %nsamp = length(rxSamples); % samples per segment  [default = data_length], none, 0 
    
% norder =  cumulant order: 2, 3 or 4 [default = 2] 
% maxlag =  maximum cumulant lag to compute [default = 0] 
%overlap = percentage overlap of segments [default = 0] 
                              %	overlap is clipped to the allowed range of [0,99]. 
%flag = 'biased' or 'unbiased'  [default = 'biased'] 
%k1,k2  - specify the slice of 3rd or 4th order cumulants


    %y_cum = cumest(y,norder,maxlag,nsamp,overlap,flag,k1,k2)
     norder = 4;
    maxlag=0;nsamp=0;overlap=0;flag='biased';k1=0;k2=0;
    y_cum = cumest(rxSamples,norder,maxlag,nsamp,overlap,flag,k1,k2)
       
   % decoding, demodulation
    
    % Remove transients from the beginning, trim to size, and normalize
    frame = helperModClassFrameGenerator(rxSamples, spf, spf, transDelay, sps);
    
    % Add to frame store
    add(frameStore, frame, modulationTypes(modType));
  end
  
 

end 

