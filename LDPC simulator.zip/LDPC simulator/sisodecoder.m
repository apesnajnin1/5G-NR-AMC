n=6;
r = 1 + 0.8*randn(1,n) % sigma = 0.8
l = (2/(0.8)^2)*r;
[m1,pos]=min(abs(l));
m2 = min(abs(l([1:pos - 1 pos + 1:n])));
lext = S*sign(l).*[m1 m1 m1 m1 m2 m1];