function cword = nrldpc_encode(mb,nb,B,z,s,k)

%B: base matrix
%z: expansion factor
%x: message vector, length = (#cols(B)-#rows(B))*z
%cword: codeword vector, length = #cols(B)*z

%[mb,nb] = size(B);

cword = zeros(1, nb*z);
s = s';
%s = [s zeros(1,numel(cword)-numel(s))]
s = [s zeros(1, k-length(s))];
cword(1:k) = s;

%double-diagonal encoding
temp = zeros(1,z);
for i = 1:4 %row 1 to 4
    for j = 1:nb-mb %message columns
        temp = mod(temp + mul_sh(s((j-1)*z+1:j*z), B(i,j)),2);
    end
end 

if B(2,nb-mb+1) == -1
    pl_sh = B(3,nb-mb+1);
else
    pl_sh = B(2,nb-mb+1);
end
cword((nb-mb)*z+1:(nb-mb+1)*z) = mul_sh(temp,z-pl_sh); %p1

%Find p2, p3, p4
for i = 1:3
    temp = zeros (1,z);
    for j = 1:nb-mb+i
        temp = mod(temp + mul_sh(cword((j-1)*z+1:j*z),B(i,j)),2);
    end
    cword((nb-mb+i)*z+1:(nb-mb+i+1)*z) = temp;
end 

%Remaining parities
for i = 5:mb
    temp = zeros(1,z);
    for j = 1:nb-mb+4 
        temp = mod(temp + mul_sh(cword((j-1)*z+1:j*z),B(i,j)),2);
    end
    cword((nb-mb+i-1)*z+1:(nb-mb+i)*z) = temp;
end
