p = dvbs2ldpc(2/3);
ldpcEnc = comm.LDPCEncoder(p);
ldpcDec = comm.LDPCDecoder(p);
%qpskMod = comm.QPSKModulator('BitInput',true);
%qpskDemod = comm.QPSKDemodulator('BitOutput',true,...
%    'DecisionMethod','Approximate log-likelihood ratio', ...
%    'VarianceSource','Input port');
%errorCnt = comm.ErrorRate;
%snrVec = [0 0.2 0.4 0.6 0.65 0.7 0.75 0.8];
%snr = 30
%ber = zeros(length(snr),1);

msgLength = size(p,2) - size(p,1);
data = logical(randi([0 1],1,msgLength)); 
encData = ldpcEnc(data);      


%for k = 1:length(snrVec)
   % noiseVar = 1/10^(snrVec(k)/10);
   % errorStats = zeros(1,3);
   % while errorStats(2) <= 200 && errorStats(3) < 5e6
        %data = logical(randi([0 1],32400,1))   % Generate binary data
       % msgLength = size(p,2) - size(p,1);
       % data = logical(randi([0 1],1,msgLength)); 
       % encData = ldpcEnc(data);                % Apply LDPC encoding
       % modSig = qpskMod(encData);              % Modulate
       % rxSig = awgn(modSig,snrVec(k));         % Pass through AWGN channel
       % demodSig = qpskDemod(rxSig,noiseVar);   % Demodulate
       % rxData = ldpcDec(demodSig);             % Decode LDPC
       % errorStats = errorCnt(data,rxData);     % Compute error stats
    %end
    
    % Save the BER for the current Eb/No and reset the error rate counter
    %ber(k) = errorStats(1);
    %reset(errorCnt)
%end 

%semilogy(snrVec,ber,'-o')
%grid
%xlabel('SNR (dB)')
%ylabel('Bit Error Rate')