function x = getldpcrate(s,codingrate,EbN0dB, SNR)
% The function getldpcrate returns the LDPC encoding with different rate
% where codingrate is rate of LDPC code, EbN0dB is SNR value in dB. 
% Base Matrice 1

%EbN0dB = 2;
%offset = 2;
%Rate = 1/2;
%Rate = 1/3;

maxiters = 10;
rmax = 40;
maxqr = 30;
maxqL = 127;


load a_presentation_for_Prof_Chang/My_code/modulation_classification/NR_1_2_20.txt
B = NR_1_2_20;
[mb,nb] = size(B);
z = 20; % expansion factor


Slen = sum(B(:)~= -1); %number of non -1 in B
Slenmax = max(sum(B ~= -1,2));

kb = nb - mb;
k = kb*z; %number of message bits 

nbRM = ceil(kb/codingrate) + 2; %number of columns of part of parity-check matrix
n = nbRM - kb;
mbRM = nbRM - kb;

EbN0 = 10^(EbN0dB/10);
sigma = sqrt(1/(2*(k/n)*EbN0));

cword = nrldpc_encode(mb,nb,B,z,s,k); 
cword = cword(1:n);

awgnChannel = comm.AWGNChannel(...
  'NoiseMethod', 'Signal to noise ratio (SNR)', ...
  'SignalPower', 1, ...
  'SNR', SNR); 

%init_x = cword + sigma*randn(1,n) %AWGN channel I 
init_x = step(awgnChannel, cword);

%quantization
    %y = floor(init_y/rmax*maxqr);
    x = ceil(init_x/rmax*maxqr);
    x(x>maxqr) = maxqr;
    x(x<-(maxqr+1)) = -(maxqr+1);
    
    
    
    
%Nbiterrs = 0; Nblkerrs = 0; Nblocks = 1;

%for i = 1: Nblocks
   % msg = randi([0 1],1,k); %generate random k-bit message
    
    %Encoding
    %cword = nrldpc_encode(B,z,msg); 
        
    %s = 1 - 2*cword; %BPSK bit to symbol conversion
    %r = cword + sigma*randn(1,n); %AWGN channel I
    
    %Puncturing of message
    %init_coding(1:2*z) = 0   
%end 
end
