function result=testrun()
loops=5;
result=zeros(1,loops);
cloudfor x=1:loops
    %cf:datafile=f1.mat,f2.mat,f3.mat,f4.mat,f5.mat
    load(['f' num2str(x) '.mat'])
    result(x)=sum(data);
cloudend
end