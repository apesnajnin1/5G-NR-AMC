classdef FrameStoreOutputFormat
  enumeration
    IQAsRows
    IQAsPages
  end
end