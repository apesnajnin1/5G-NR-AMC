function gendata()
loops = 5;
for x = 1:loops
    data=rand(1,10);
    save(['f' num2str(x) '.mat'],'data')
end
end